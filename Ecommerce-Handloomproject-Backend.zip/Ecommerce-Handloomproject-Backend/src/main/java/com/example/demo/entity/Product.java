package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Entity
@Table(name = "products")
public class Product {

	@Id
	@Column(name = "productid")
	@Min(value = 1, message = "Product ID must be greater than or equal to 1")
	@Digits(integer = 10, fraction = 0, message = "Item ID should be a number")
	private int item_id;
	@NotBlank(message = "Item name cannot be blank")
	@Column(name = "pname")
	private String pname;

	@NotNull(message = "Price cannot be null")
	@Positive(message = "Price must be a positive value")
	private Double price;

	@NotBlank(message = "Image URL cannot be blank")
	@Column(name = "img")
	private String img;
	
	@Column(name="Quantity_in_Stock")
	private String quantitystock;

	public Product() {

	}

	public Product(
			@Min(value = 1, message = "Product ID must be greater than or equal to 1") @Digits(integer = 10, fraction = 0, message = "Item ID should be a number") int item_id,
			@NotBlank(message = "Item name cannot be blank") String pname,
			@NotNull(message = "Price cannot be null") @Positive(message = "Price must be a positive value") Double price,
			@NotBlank(message = "Image URL cannot be blank") String img, String quantitystock) {
		super();
		this.item_id = item_id;
		this.pname = pname;
		this.price = price;
		this.img = img;
		this.quantitystock = quantitystock;
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getQuantitystock() {
		return quantitystock;
	}

	public void setQuantitystock(String quantitystock) {
		this.quantitystock = quantitystock;
	}

	@Override
	public String toString() {
		return "Product [item_id=" + item_id + ", pname=" + pname + ", price=" + price + ", img=" + img
				+ ", quantitystock=" + quantitystock + "]";
	}
}

	