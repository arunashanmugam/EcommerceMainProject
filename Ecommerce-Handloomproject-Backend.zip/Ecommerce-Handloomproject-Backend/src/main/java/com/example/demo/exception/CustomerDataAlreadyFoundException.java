package com.example.demo.exception;

public class CustomerDataAlreadyFoundException  extends RuntimeException {
	
	 public CustomerDataAlreadyFoundException(String message) {
	        super(message);
	

}
}
