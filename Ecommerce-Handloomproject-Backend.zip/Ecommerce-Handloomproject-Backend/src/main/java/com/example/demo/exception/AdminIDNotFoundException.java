package com.example.demo.exception;

public class AdminIDNotFoundException extends Exception {

	public AdminIDNotFoundException(String message) {
		super(message);
	}

}
